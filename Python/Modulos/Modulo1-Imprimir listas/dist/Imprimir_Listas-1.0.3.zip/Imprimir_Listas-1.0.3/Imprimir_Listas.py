"""Este codigo imprime cada item dentro una lista, imprimiendo a su vez, cada item de listas que se encuentren anidadas"""
def repetir(x, opc=False, ind=0):
    #x es la lista que se lee, si x es una lista pasa al for el cual manda a llamar a la funcion
    #opc permite indentar los resultados si es true, en caso de no especificarlo no se indenta
    #ind establece el nivel que se indentara algo, (iniciando desde el primer nivel).
    if isinstance(x,list):
        for elemento in x:
            repetir(elemento, opc, ind+1)
    #En caso de que no sea una lista el elemento, se imprime
    else:
        if opc==True:
            for tab in range(ind):
                print ("\t"*ind, end='')
        print (str(x))