from distutils.core import setup

setup(
		name		= 'Imprimir_Listas',
		version		= '1.0.3',
		py_modules	= ['Imprimir_Listas'],
		author		= 'LIMA',
		author_email= 'luisivanmorett@gmail.com',
		url			= 'https://plus.google.com/+LuisIv%C3%A1nMorett/posts',
		description = 'Imprime items de listas y de sus respectivas listas anidadas'
	)